﻿using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;

namespace CCAM.Models
{
    public class FileUploadViewModel
    {
        [Required(ErrorMessage = "Please select a file.")]
        [Display(Name = "Select File to Upload")]
        public IFormFile File { get; set; }
    }
}
