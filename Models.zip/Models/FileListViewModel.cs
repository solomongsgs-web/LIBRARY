﻿using System.ComponentModel.DataAnnotations;

namespace CCAM.Models
{
    public class FileListViewModel
    {
        public string LocalPath { get; set; }
        public string OutputPath { get; set; }
        public List<SftpFileInfo> Folder1Files { get; set; }
        public List<SftpFileInfo> Folder2Files { get; set; }
        public IEnumerable<string> LocalFiles { get; set; }
       
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime EventDateTime { get; set; }

        [Required(ErrorMessage = "Please select a file.")]
        [Display(Name = "Select File to Upload")]
        public IFormFile File { get; set; }

    }
}
