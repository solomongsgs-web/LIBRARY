﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NuGet.DependencyResolver;
using System.IO;
using System.IO;
using System.Runtime.Intrinsics.X86;
using System.Threading.Tasks;
using WinSCP;
using SessionOptions = WinSCP.SessionOptions;

namespace CCAM.Services
{
    public class SftpService
    {
        private readonly IConfiguration _configuration;
        private IConfigurationSection sftpSettings;
        private readonly SftpSettings _settings;
        private readonly ILogger<SftpService> _logger;
        public SftpService(IOptions<SftpSettings> settings, ILogger<SftpService> logger, IConfiguration configuration)
        {
            _settings = settings.Value;
            _logger = logger;
            _configuration = configuration;
        }
        public IConfigurationSection GetSftpSettings()
        {
            return sftpSettings;
        }

        //TESTING CONNECTION
        public bool TestConnection()
        {
            try
            {
                // Setup session options from settings
                var sessionOptions = new SessionOptions
                {
                    Protocol = Protocol.Sftp,
                    HostName = _settings.Host,
                    PortNumber = _settings.Port,
                    UserName = _settings.Username,
                    Password = _settings.Password,
                    SshHostKeyFingerprint = _settings.SshHostKeyFingerprint
                };

                // Log that a connection attempt is being made
                _logger.LogInformation("Attempting to connect to SFTP server: {HostName}", _settings.Host);

                using (var session = new Session())
                {
                    session.Open(sessionOptions);
                    _logger.LogInformation("Successfully connected to SFTP server.");
                    return true;
                }
            }
            catch (SessionRemoteException ex)
            {
                _logger.LogError(ex, "SFTP connection failed with a session exception. Error: {ErrorMessage}", ex.Message);
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An unexpected error occurred during SFTP connection test. Error: {ErrorMessage}", ex.Message);
                return false;
            }
        }

        public bool TestSftpConnection(string hostName, string userName, string password, string sshHostKeyFingerprint = null)
        {
            try
            {
                SessionOptions sessionOptions = new SessionOptions
                {
                    Protocol = Protocol.Sftp,
                    HostName = hostName,
                    UserName = userName,
                    Password = password,
                    // Optional: For added security, provide the SshHostKeyFingerprint
                    // You can obtain this from WinSCP when connecting manually for the first time
                    SshHostKeyFingerprint = sshHostKeyFingerprint
                };

                using (Session session = new Session())
                {
                    session.Open(sessionOptions);
                    // If session.Open() completes without throwing an exception, the connection is successful.
                    session.Close();
                    return true;
                }
            }
            catch (Exception ex)
            {
                // Log the exception for debugging purposes
                Console.WriteLine($"SFTP connection failed: {ex.Message}");
                return false;
            }
        }

        public void DownloadFile(string remoteFileName, string localPath)
        {
            var sftpSettings = _configuration.GetSection("SftpSettings");
            var sessionOptions = new WinSCP.SessionOptions
            {
                Protocol = Protocol.Sftp,
                HostName = sftpSettings["Host"],
                UserName = sftpSettings["Username"],
                Password = sftpSettings["Password"],
                SshHostKeyFingerprint = sftpSettings["SshHostKeyFingerprint"]
            };
            using (var session = new Session())
            {
                try
                {
                    // Connect to the SFTP server
                    session.Open(sessionOptions);

                    // Define remote and local paths
                    string remoteFilePath = Path.Combine(sftpSettings["RemoteFilePath"], remoteFileName).Replace("\\", "/");
                    string localFilePath = Path.Combine(localPath, remoteFileName);

                    // Download the file
                    session.GetFiles(remoteFilePath, localFilePath);
                   
                    session.Close();
                }
                catch (Exception ex)
                {
                    // Log the exception for troubleshooting
                    throw new Exception($"SFTP download failed: {ex.Message}");
                }
            }
        }

        public bool UploadFile(string localFilePath, string remoteFileName)
        {
            try
            {
                var sftpSettings = _configuration.GetSection("SftpSettings");
                var sessionOptions = new WinSCP.SessionOptions
                {
                    Protocol = Protocol.Sftp,
                    HostName = sftpSettings["Host"],
                    UserName = sftpSettings["Username"],
                    Password = sftpSettings["Password"],
                    SshHostKeyFingerprint = sftpSettings["SshHostKeyFingerprint"]
                };
                using (var session = new Session())
                {
                    // Connect to the SFTP server
                    session.Open(sessionOptions);

                    string remoteFilePath = Path.Combine(sftpSettings["RemoteSendFilePath"], remoteFileName).Replace("\\", "/");
                    //string localFile = Path.Combine(localFilePath, remoteFileName);


                    TransferOptions transferOptions = new TransferOptions
                    {
                        TransferMode = TransferMode.Binary
                    };

                    TransferOperationResult transferResult = session.PutFiles(localFilePath, remoteFilePath, false, transferOptions);

                    transferResult.Check(); // Throws an exception if the transfer fails

                    return true;
                }          
            }
            catch (Exception ex)
            {
                // Log the exception for debugging
                Console.WriteLine($"SFTP upload failed: {ex.Message}");
                return false;
            }
        }



    }
}
