﻿using Microsoft.AspNetCore.Mvc;
using CCAM.Models;
using Microsoft.Extensions.Configuration;
using System.IO;
using CCAM.Services;

namespace CCAM.Services
{
    public class FileConversionService
    {
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly IConfiguration _configuration;
        public FileConversionService(IWebHostEnvironment webHostEnvironment, IConfiguration configuration)
        {
            _webHostEnvironment = webHostEnvironment;
            _configuration = configuration;
        }
        public string ReadTextFile(string fileName)
        {
            //string filePath = Path.Combine(_webHostEnvironment.ContentRootPath, "Data", fileName); // Adjust folder as needed
            if (File.Exists(fileName))
            {
                return File.ReadAllText(fileName);
            }
            return null; // Handle file not found
        }

        public void WriteNewTextFile(string newFileName, string content)
        {
            string newFilePath = Path.Combine(_webHostEnvironment.WebRootPath, "Output", newFileName); // Adjust folder as needed
            File.WriteAllText(newFilePath, content);
        }
        public string GetFileFullPath(string strFile)
        {
            //Get Download Directory
            var MFT_DOWNLOAD_FOLDER = Path.Combine(_webHostEnvironment.WebRootPath, path2: _configuration.GetSection("SftpSettings")["LocalDownloadPath"]);
            string cFile = "";
            if (strFile.Contains("GEFU") == true)
            {
                {
                    cFile = MFT_DOWNLOAD_FOLDER;
                    cFile = cFile + "\\" + strFile;
                    return cFile;
                }
            }
            return cFile;
        }
        public string CreateNewFile(string strFile)
        {
            //Get Output Directory
            var MFT_UPLOAD_FOLDER = Path.Combine(_webHostEnvironment.WebRootPath, path2: _configuration.GetSection("SftpSettings")["OutputFilePath"]);

            string cFile = "";
            if (strFile.Contains("GEFU") == true)
            {
                {
                    cFile = MFT_UPLOAD_FOLDER;
                    if (strFile.Length > 19)
                        cFile = cFile + "\\GEFUUP" + "_ECDEP_" + strFile.Substring(18, 11) + ".txt"; // strFile.Substring(4, 8) + ".txt";
                    else
                        cFile = cFile + "\\GEFUUP" + "_ECDEP_" + strFile.Substring(4, 11) + ".txt"; // strFile.Substring(4, 8) + ".txt";
                    return cFile;
                }
            }
            return cFile;
        }


    }
}
