﻿using CCAM.Data;
using CCAM.Models;
using CCAM.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing.Constraints;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Text;
using System.Xml.Linq;
using WinSCP;
using SessionOptions = WinSCP.SessionOptions;


namespace CCAM.Controllers
{
    public class UploadController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _hostingEnvironment;
        private readonly SftpService _sftpService;
        private readonly FileConversionService _fileConversionService;
        private readonly AppDBContext _context;
        private string strBillerCodeNotFound;
       
        public int processFileCtr = 0;

        public UploadController(IConfiguration configuration, IWebHostEnvironment hostingEnvironment, SftpService sftpService, FileConversionService fileConversionService, AppDBContext context)
        {
            _configuration = configuration;
            _hostingEnvironment = hostingEnvironment;
            _sftpService = sftpService;
            _fileConversionService = fileConversionService;
            _context = context;
        }
       
        [HttpGet]
        public IActionResult Index()
        {
            var viewModel = new FileListViewModel();
            var folder1Path = Path.Combine(_hostingEnvironment.WebRootPath, path2: _configuration.GetSection("SftpSettings")["LocalDownloadPath"]);
            var folder2Path = Path.Combine(_hostingEnvironment.WebRootPath, path2: _configuration.GetSection("SftpSettings")["OutputFilePath"]);

            // Get files from Folder 1
            if (Directory.Exists(folder2Path))
            {
                viewModel.Folder1Files = Directory.GetFiles(folder2Path)
                    .Select(filePath => new SftpFileInfo
                    {
                        FileName = Path.GetFileName(filePath),
                        FileSize = Path.GetFileName(filePath).Length,
                        IsSelected = false
                    })
                    .ToList();
            }
            else
            {
                viewModel.Folder2Files = new List<SftpFileInfo>();
            }
            int sftpFilesCtr = viewModel.Folder1Files.Count;
            if (sftpFilesCtr > 0)
            {
                TempData["Message1"] = "There are " + sftpFilesCtr.ToString() + " files for uploading to MFT.";
            }

            // Display files from MFT 
            //FOR SFTP
            var sessionOptions = new SessionOptions
            {
                Protocol = Protocol.Sftp,
                HostName = _configuration.GetSection("SftpSettings")["Host"],
                UserName = _configuration.GetSection("SftpSettings")["Username"],
                Password = _configuration.GetSection("SftpSettings")["Password"],
                SshHostKeyFingerprint = _configuration.GetSection("SftpSettings")["SshHostKeyFingerprint"] //"ssh-rsa 2048 xxxxxxxxxxx..." // Get this from your server
            };
            var _remotePath = _configuration.GetSection("SftpSettings")["RemoteSendFilePath"];
            try
            {
                using (var session = new Session())
                {
                    session.Open(sessionOptions);

                    var directoryInfo = session.ListDirectory(_remotePath);

                    viewModel.Folder2Files = directoryInfo.Files
                        .Where(f => !f.IsDirectory)    // && !f.IsSymbolicLink)
                        .Select(f => new SftpFileInfo
                        {
                            FileName = f.Name,
                            FileSize = f.Length,
                            LastModified = f.LastWriteTime,
                            IsSelected = false // Initialize as not selected
                        })
                        .ToList();
                }
            }
            catch (SessionRemoteException ex)
            {
                // Handle exceptions appropriately
                ModelState.AddModelError("", $"Could not list directory: {ex.Message}");
                viewModel.Folder2Files = new List<SftpFileInfo>();
            }
             //Number of files on MFT
            int outFilesCtr = viewModel.Folder2Files.Count;
            if (outFilesCtr > 0)
            {
                TempData["Message2"] = outFilesCtr.ToString() + " files was uploaded";
            }
            viewModel.LocalPath = folder2Path; //output folder
            viewModel.OutputPath = _remotePath;
          
            viewModel.EventDateTime = DateTime.Now;
            if (TempData["Message1"] != null)
            {
                ViewBag.Message1 = TempData["Message1"];  // Pass to the view
            }
            if (TempData["Message2"] != null)
            {
                ViewBag.Message2 = TempData["Message2"];  // Pass to the view
            }
            if (TempData["StatusMessage"] != null)
            {
                ViewBag.Message3 = TempData["StatusMessage"];  // Pass to the view
            }
            return View(viewModel);
        }
        [HttpPost]
        public IActionResult ProcessFiles(FileListViewModel model)
        {
            ViewBag.Message1 = "";
            ViewBag.Message2 = "";
            ViewBag.Message3 = "";
            var blnProcessStatus = true;
            //var localDownloadPath = _configuration.GetSection("SftpSettings")["LocalDownloadPath"];
            var remotePath = _configuration.GetSection("SftpSettings")["RemoteSendFilePath"];
            var localDownloadPath = Path.Combine(_hostingEnvironment.WebRootPath, path2: _configuration.GetSection("SftpSettings")["OutputFilePath"]);
            var localFilePath = string.Empty;

            //Directory.CreateDirectory(localDownloadPath);

            var selectedFiles = model.Folder1Files.Where(f => f.IsSelected).ToList();

            // Add your logic to process the selected files here
            int count = selectedFiles.Count;
            for (int ctr = 0; ctr < count; ctr++)
            {
                // Handles the file download request
                if (string.IsNullOrEmpty(selectedFiles[ctr].FileName.ToString()))
                {
                    return BadRequest("File name is required.");
                }
                try
                {
                    //UPLOADING 
                    localFilePath = localDownloadPath + "\\" + selectedFiles[ctr].FileName.ToString();
                    remotePath = selectedFiles[ctr].FileName.ToString();
                    blnProcessStatus = _sftpService.UploadFile(localFilePath, remotePath);
                    if (blnProcessStatus == true)
                    {
                        processFileCtr = processFileCtr + 1;
                    }

                    if (TempData["Message1"] != null)
                    {
                        ViewBag.Message1 = TempData["Message1"];  // Pass to the view
                    }
                    if (TempData["Message2"] == null)
                    {
                        TempData["Message2"] = processFileCtr.ToString() + " files was uploaded";
                        ViewBag.Message2 = TempData["Message2"];  // Pass to the view
                    }
                    if (TempData["StatusMessage"] != null)
                    {
                        ViewBag.Message3 = TempData["StatusMessage"];  // Pass to the view
                    }
                }
                catch (Exception ex)
                {
                    // Handle exceptions (e.g., file not found, connection error)
                    return StatusCode(500, $"An error occurred during the download: {ex.Message}");
                }
                Console.WriteLine($"Selected file: {selectedFiles[ctr].FileName}");
            }
            // Serve the downloaded file to the user
            //var filePath = Path.Combine(localDownloadPath, selectedFiles[count-1].FileName.ToString());
            //var fileBytes = System.IO.File.ReadAllBytes(filePath);
            //return File(fileBytes, "application/octet-stream", selectedFiles[count-1].FileName.ToString());
            // For example, download them, delete them, etc.
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult ProcessSelectedFiles(List<SftpFileInfo> selectedFiles)
        {
            // Process the selected files (e.g., download, delete)
            foreach (var file in selectedFiles.Where(f => f.IsSelected))
            {
                // Perform actions on selected files
                Console.WriteLine($"Selected file: {file.FileName}");
            }

            return RedirectToAction("Index"); // Redirect back to the file list
        }



    }
}
