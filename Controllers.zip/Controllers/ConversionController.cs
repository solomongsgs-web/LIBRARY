﻿using CCAM.Data;
using CCAM.Models;
using CCAM.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing.Constraints;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using System;
using System.IO;
using System.Text;
using System.Xml.Linq;
using WinSCP;

namespace SFTP.Controllers
{
    public class ConversionController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _hostingEnvironment;
        private readonly SftpService _sftpService;
        private readonly FileConversionService _fileConversionService;
        private readonly AppDBContext _context;
        private string strBillerCodeNotFound;
        double NoDeb = 0;
        double NoCre = 0;
        double TotDeb = 0;
        double TotCre = 0;
        public int processFileCtr = 0;

        public ConversionController(IConfiguration configuration, IWebHostEnvironment hostingEnvironment, SftpService sftpService, FileConversionService fileConversionService, AppDBContext context)
        {
            _configuration = configuration;
            _hostingEnvironment = hostingEnvironment;
            _sftpService = sftpService;
            _fileConversionService = fileConversionService;
            _context = context;
        }
        public IActionResult Index()
        {
            var viewModel = new FileListViewModel();
            var folder1Path = Path.Combine(_hostingEnvironment.WebRootPath, path2: _configuration.GetSection("SftpSettings")["LocalDownloadPath"]);
            var folder2Path = Path.Combine(_hostingEnvironment.WebRootPath, path2: _configuration.GetSection("SftpSettings")["OutputFilePath"]);

            // Get files from Folder 1
            if (Directory.Exists(folder1Path))
            {
                viewModel.Folder1Files = Directory.GetFiles(folder1Path)
                    .Select(filePath => new SftpFileInfo
                    {
                        FileName = Path.GetFileName(filePath),
                        FileSize = Path.GetFileName(filePath).Length,
                        IsSelected = false
                    })
                    .ToList();
            }
            else
            {
                Directory.CreateDirectory(folder1Path);
                viewModel.Folder1Files = new List<SftpFileInfo>();
            }




            int sftpFilesCtr = viewModel.Folder1Files.Count;
            if (sftpFilesCtr > 0)
            {
                TempData["Message1"] = "There are " + sftpFilesCtr.ToString() + " files for conversion.";
            }

            // Get files from Folder 2
            if (Directory.Exists(folder2Path))
            {
                viewModel.Folder2Files = Directory.GetFiles(folder2Path)
                    .Select(filePath => new SftpFileInfo
                    {
                        FileName = Path.GetFileName(filePath),
                        FileSize = Path.GetFileName(filePath).Length,
                        IsSelected = false
                    })
                    .ToList();
            }
            else
            {
                Directory.CreateDirectory(folder2Path);
                viewModel.Folder2Files = new List<SftpFileInfo>();
            }
            int outFilesCtr = viewModel.Folder2Files.Count;
            if (outFilesCtr > 0)
            {
                TempData["Message2"] = outFilesCtr.ToString() + " files was converted";
            }
            viewModel.LocalPath = folder1Path;
            viewModel.OutputPath = folder2Path;
            viewModel.EventDateTime = DateTime.Now;
            if (TempData["Message1"] != null)
            {
                ViewBag.Message1 = TempData["Message1"];  // Pass to the view
            }
            if (TempData["Message2"] != null)
            {
                ViewBag.Message2 = TempData["Message2"];  // Pass to the view
            }
            if (TempData["StatusMessage"] != null)
            {
                ViewBag.Message3 = TempData["StatusMessage"];  // Pass to the view
            }
            return View(viewModel);
        }

        //Convert files 
        [HttpPost]
        public IActionResult ProcessSelectedFiles(FileListViewModel model)
        {
            ViewBag.Message1 = "";
            ViewBag.Message2 = "";
            ViewBag.Message3 = "";
            var blnProcessStatus = true;
            // Access selected files on RAW GEFU LISTS: model.Files.Where(f => f.IsSelected)
            var selectedFiles = model.Folder1Files.Where(f => f.IsSelected).ToList();
            // Add your logic to process the selected files here
            int count = selectedFiles.Count;
            for (int ctr = 0; ctr <= count-1; ctr++)
            {
                // Handles the file download request
                if (string.IsNullOrEmpty(selectedFiles[ctr].FileName.ToString()))
                {
                    return BadRequest("File name is required.");
                }
                try
                {
                    blnProcessStatus = ConvertGEFUFile(selectedFiles[ctr].FileName.ToString());
                    if (blnProcessStatus == true)
                    {
                        processFileCtr = processFileCtr + 1;
                    }

                    if (TempData["Message1"] != null)
                    {
                        ViewBag.Message1 = TempData["Message1"];  // Pass to the view
                    }
                    if (TempData["Message2"] == null)
                    {
                        TempData["Message2"] = processFileCtr.ToString() + " files was converted";
                        ViewBag.Message2 = TempData["Message2"];  // Pass to the view
                    }
                    if (TempData["StatusMessage"] != null)
                    {
                        ViewBag.Message3 = TempData["StatusMessage"];  // Pass to the view
                    }
                }
                catch (Exception ex)
                {
                    // Handle exceptions (e.g., file not found, connection error)
                    return StatusCode(500, $"An error occurred during the download: {ex.Message}");
                }
                Console.WriteLine($"Selected file: {selectedFiles[ctr].FileName}");
            }
            //DONE CONVERTING 
            
            var folder1Path = Path.Combine(_hostingEnvironment.WebRootPath, path2: _configuration.GetSection("SftpSettings")["LocalDownloadPath"]);
            string folderPath = Path.Combine(_hostingEnvironment.WebRootPath, "text");
            string[] filePaths = Directory.GetFiles(folder1Path);

            // Or another folder
            //string fullPath = Path.Combine(folderPath, fileName);
            int counter = filePaths.Length;
            for (int ctr = 0; ctr <= counter - 1; ctr++)
            {
                string sFileName = filePaths[ctr].ToString();
                if (System.IO.File.Exists(sFileName));
                {
                    System.IO.File.Delete(sFileName);

                }
            }
               


            // Perform actions with the selected files (e.g., download, delete)
            // ...
            return RedirectToAction("Index"); // Redirect back or to a confirmation page
        }


        public bool ConvertGEFUFile(string remoteFileName)
        {

            string fileContent;
            bool blnConvSuccess = true;
            var GEFUFile = _fileConversionService.GetFileFullPath(remoteFileName);
            var GEFUFileName = Path.GetFileName(remoteFileName);
            var newGEFUFile = _fileConversionService.CreateNewFile(GEFUFileName);
            StringBuilder contentBuilder = new StringBuilder();
            if (System.IO.File.Exists(GEFUFile))
            {
                fileContent = System.IO.File.ReadAllText(GEFUFile);
                string[] lines = System.IO.File.ReadAllLines(GEFUFile);

                using (StreamReader reader = new StreamReader(GEFUFile))
                {
                    string line;
#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
                    while ((line = reader.ReadLine()) != null)
                    {
                        //Read per line
                        // Read the contents
                        blnConvSuccess = ConvertGEFUATPIFile(newGEFUFile, line, newGEFUFile);
                        if (blnConvSuccess == false)
                        {
                            //FAILED CONVERSION ON RECORD
                            if (System.IO.File.Exists(newGEFUFile) == true)
                            {
                                System.IO.File.Delete(newGEFUFile);
                                //result = customMessage.Text("Conversion Failed", "Close this form and add record on Biller Profile - database.", "erro", MessageBoxButtons.OK);
                                TempData["StatusMessage"] = "Failed to convert Biller Code : " + strBillerCodeNotFound + " not on Database. Please add to Biller Profiles.";

                            }
                            return blnConvSuccess;
                        }
                        contentBuilder.AppendLine(line);
                    }
#pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.
                }
                return blnConvSuccess;
            }
            else
            {
                fileContent = "Source file not found.";
                // Handle the case where the source file doesn't exist
            }
            return blnConvSuccess;
        }

        public bool ConvertGEFUATPIFile(string sNewGEFUFile, string strLine, string GEFUFile)
        {
            bool retVal = true;
            string sTime = "";
            string sTran = "";
            string sDetail = "";
            string strTotCre = "";
            string strTotDeb = "";
            string strDeb = "";
            string strCre = "";
            string sGEFU = ""; // GEFUFile.Substring(0, 4) + GEFUFile.Substring(13, 11); //GEFUFile.Substring(13, 8);
            if (strLine.Length > 0)
            {
                try
                {
                    //variables
                    int retCode = 0;
                    int errFound = 0;

                    string HRecType = string.Empty;
                    string sHeaderDate = string.Empty;

                    string DRecType = string.Empty;
                    string TranType = string.Empty;
                    string AccountNo = string.Empty;
                    string BranchCode = string.Empty;
                    string TranCode = string.Empty;
                    string TranDate = string.Empty;
                    string DCFlag = string.Empty;
                    string ValueDate = string.Empty;
                    string TranCurr = string.Empty;
                    string AmountLCurr = string.Empty;
                    string AmountTCurr = string.Empty;
                    string ConvRate = string.Empty;
                    string RefNo = string.Empty;
                    string DocNo = string.Empty;
                    string TranDesc = string.Empty;
                    string BenefIC = string.Empty;
                    string BenefName = string.Empty;
                    string BenefAddr1 = string.Empty;
                    string BenefAddr2 = string.Empty;
                    string BenefAddr3 = string.Empty;
                    string City = string.Empty;
                    string State = string.Empty;
                    string Country = string.Empty;
                    string ZipCode = string.Empty;
                    string OptFlag = string.Empty;
                    string IssuerCode = string.Empty;
                    string PayBranch = string.Empty;
                    string FutureDatedFlag = string.Empty;
                    string MISCode = string.Empty;
                    string ProcessingFlag = string.Empty;
                    string ReasonFlag = string.Empty;
                    string UDT1 = string.Empty;
                    string UDT2 = string.Empty;
                    string UDT3 = string.Empty;
                    string UDT4 = string.Empty;
                    string UDT5 = string.Empty;
                    string UDT6 = string.Empty;
                    string UDT7 = string.Empty;
                    string UDT8 = string.Empty;
                    string UDT9 = string.Empty;
                    string UDT10 = string.Empty;
                    string UDT11 = string.Empty;
                    string UDT12 = string.Empty;
                    string UDT13 = string.Empty;

                    string TRecType = string.Empty;
                    string NoDebit = string.Empty;
                    string NoCredit = string.Empty;

                    string TotalDebit = string.Empty;
                    string TotalCredit = string.Empty;
                    string CFlag = "0";

                    string sBillerCode = string.Empty;
                    string ConvAccountNo = string.Empty;

                    if (strLine.Length > 0)
                    {
                        //Header 
                        if (strLine.Substring(0, 1) == "1")
                        {
                            HRecType = strLine.Substring(0, 1);
                            sHeaderDate = strLine.Substring(1, 8);
                            sHeaderDate = HRecType + sHeaderDate;
                            WriteText(sHeaderDate, sNewGEFUFile);
                            //WriteToDBHeader(sHeaderDate, sGEFU);
                        }
                        //Transactions
                        if (strLine.Substring(0, 1) == "2")
                        {

                            DRecType = strLine.Substring(0, 1);
                            TranType = strLine.Substring(1, 2);
                            AccountNo = strLine.Substring(3, 16);
                            AccountNo = AccountNo.Trim();
                            int numCode = Convert.ToInt32(AccountNo);
                            sBillerCode = numCode.ToString();// AccountNo;
                            string sAcct = string.Empty;

                            string[] ResAcctN;


                            var biller = _context.Biller
                                .FirstOrDefault(p => p.BillerCode == sBillerCode);
                            if (biller == null)
                            {

                                strBillerCodeNotFound = sBillerCode;

                            }
                            else
                            {
                                AccountNo = biller.AcctNo1;
                            }
                            string sRes = "";// SearchRecordBillerProfile(sBillerCode);   //GetConvertedAccountNo(AccountNo);
                            if (sRes.Length > 16)
                            {
                                ResAcctN = sRes.Split(',');
                                AccountNo = ResAcctN[1].ToString();
                            }
                            else
                            {
                                ResAcctN = null;
                            }

                            if (ResAcctN == null)
                            {

                            }
                            else
                            {
                                if (ResAcctN.Length == 0)
                                {
                                    ResAcctN = null;
                                }
                            }
                            if (ResAcctN == null)
                            {
                                ConvAccountNo = AccountNo;//SearchRecordOnLookUp(AccountNo);
                                if (ConvAccountNo.Length < 16)
                                    ConvAccountNo = ConvAccountNo.PadLeft(16, '0');

                                if (ConvAccountNo == AccountNo)
                                {
                                    //NOT CONVERTED 
                                    Console.WriteLine("Biller Code not found");
                                    //result = customMessage.Text("Conversion Failed", "Biller Code not found on database.", "erro", MessageBoxButtons.OK);
                                    sAcct = AccountNo;
                                    sTime = string.Format("{0:HH:mm:ss tt}", DateTime.Now);
                                    sTime = sTime.PadRight(15, ' ');
                                    sDetail = sTime + " " + GEFUFile + "  " + "Biller Code not found" + "   " + sAcct.ToString();

                                    //WriteToLog(sDetail, fileLog);
                                    //WriteToErrorLog(sDetail, errorLog);

                                    retCode = 1;
                                    errFound = 1;
                                    retVal = false;
                                    goto exitme;
                                    //continue;
                                }
                                else
                                {
                                    //FOUND IN LOOK UP TABLE
                                    ConvAccountNo = AccountNo.PadLeft(16, '0');
                                    retVal = true;
                                }
                            }
                            else
                            {
                                CFlag = "1";
                                sAcct = AccountNo;

                                //Write to DB
                                sTime = string.Format("{0:HH:mm:ss tt}", DateTime.Now);
                                sTime = sTime.PadRight(15, ' ');
                                sDetail = sTime + " " + GEFUFile + "  " + " Account No - " + sAcct.PadRight(16, ' ') + " converted from Biller Code - " + sBillerCode.Substring(11, 5);
                                //WriteToLog(sDetail, fileLog);

                                ConvAccountNo = sBillerCode.PadLeft(16, '0'); //AccountNo = "0000188870028590";
                                if (ConvAccountNo.Length > 3)
                                {
                                    int lenAcctNo = ConvAccountNo.Length;
                                    string TrimConvAcctNo = ConvAccountNo.Substring(lenAcctNo - 3, 3);
                                    ConvAccountNo = TrimConvAcctNo.Trim();
                                }
                                //Save to Look Up
                                //SaveToLookUp(ConvAccountNo, AccountNo);
                                AccountNo = AccountNo.Trim();
                                ConvAccountNo = AccountNo.PadLeft(16, '0');
                                retVal = true;
                            }

                            BranchCode = strLine.Substring(19, 4);
                            TranCode = strLine.Substring(23, 5);
                            TranCode = TranCode.Trim().PadLeft(5, '0');
                            //TranDate = "20190730"; //strLine.Substring(28, 8);
                            TranDate = strLine.Substring(28, 8);
                            DCFlag = strLine.Substring(36, 1);
                            //ValueDate = "20190730"; //strLine.Substring(37, 8);
                            ValueDate = strLine.Substring(37, 8);
                            TranCurr = strLine.Substring(45, 5);
                            AmountLCurr = strLine.Substring(50, 14);
                            AmountTCurr = strLine.Substring(64, 14);

                            if (retCode == 0)  // || (retCode == 1))
                            {
                                if (DCFlag == "C")
                                {
                                    TotCre = TotCre + Double.Parse(AmountLCurr);
                                    NoCre = NoCre + 1;
                                }
                                if (DCFlag == "D")
                                {
                                    TotDeb = TotDeb + Double.Parse(AmountLCurr);
                                    NoDeb = NoDeb + 1;
                                }
                            }

                            ConvRate = strLine.Substring(78, 8);
                            RefNo = strLine.Substring(86, 40);
                            DocNo = strLine.Substring(126, 12);
                            TranDesc = strLine.Substring(138, 40);
                            BenefIC = strLine.Substring(178, 16);
                            BenefName = strLine.Substring(194, 120);
                            BenefAddr1 = strLine.Substring(314, 35);
                            BenefAddr2 = strLine.Substring(349, 35);
                            BenefAddr3 = strLine.Substring(384, 35);
                            City = strLine.Substring(419, 35);
                            State = strLine.Substring(454, 35);
                            Country = strLine.Substring(489, 35);
                            ZipCode = strLine.Substring(524, 35);
                            OptFlag = strLine.Substring(559, 2);
                            IssuerCode = strLine.Substring(561, 5);
                            PayBranch = strLine.Substring(566, 4);
                            FutureDatedFlag = strLine.Substring(570, 1);

                            MISCode = strLine.Substring(571, 16);
                            ProcessingFlag = strLine.Substring(587, 1);
                            ProcessingFlag = " ";
                            ReasonFlag = strLine.Substring(588, 2);
                            ReasonFlag = "  ";
                            //UDT1 = strLine.Substring(587, 60);
                            UDT1 = strLine.Substring(590, 60);
                            //UDT2 = "EC Deposit                                                  ";
                            UDT2 = strLine.Substring(650, 60);
                            UDT3 = strLine.Substring(710, 60);
                            UDT4 = strLine.Substring(770, 60);

                            UDT5 = strLine.Substring(830, 60);
                            UDT6 = strLine.Substring(890, 60);
                            UDT7 = strLine.Substring(950, 60);

                            UDT8 = strLine.Substring(1010, 60);
                            UDT9 = strLine.Substring(1070, 60);
                            UDT10 = strLine.Substring(1130, 60);

                            UDT11 = strLine.Substring(1190, 60);
                            UDT12 = strLine.Substring(1250, 60);
                            UDT13 = strLine.Substring(1310, 60);


                            if (retCode == 1)    // || (retCode == 0))
                            {
                                //NOT CONVERTED 
                                retVal = false;
                                retCode = 0;

                                //WriteToDB(strLine, sGEFU, CFlag);
                                goto exitme;
                            }
                            else
                            {
                                //CONVERTED 
                                //strLine = DRecType + TranType + ConvAccountNo.Trim() + BranchCode.PadRight(4, '0') + TranCode + TranDate + DCFlag + ValueDate + TranCurr.PadLeft(5, '0') + AmountLCurr.PadLeft(14, '0') + AmountTCurr.PadLeft(14, '0') + ConvRate.PadLeft(8, '0') + RefNo.PadRight(40) + DocNo.PadRight(12) + TranDesc.PadRight(40) + BenefIC.PadRight(16) + BenefName.PadRight(120) + BenefAddr1.PadRight(35) + BenefAddr2.PadRight(35) + BenefAddr3.PadRight(35) + City.PadRight(35) + State.PadRight(35) + Country.PadRight(35) + ZipCode.PadRight(35) + OptFlag + IssuerCode + PayBranch + FutureDatedFlag + MISCode + ProcessingFlag + ReasonFlag + UDT1 + UDT2 + UDT3 + UDT4 + UDT5 + UDT6 + UDT7 + UDT8 + UDT9 + UDT10 + UDT11 + UDT12 + UDT13;                                      
                                string NewLine = DRecType + TranType + ConvAccountNo.Trim() + BranchCode.PadRight(4, '0') + TranCode + TranDate + DCFlag + ValueDate + TranCurr.PadLeft(5, '0') + AmountLCurr.PadLeft(14, '0') + AmountTCurr.PadLeft(14, '0') + ConvRate.PadLeft(8, '0') + RefNo.PadRight(40) + DocNo.PadRight(12) + TranDesc.PadRight(40) + BenefIC.PadRight(16) + BenefName.PadRight(120) + BenefAddr1.PadRight(35) + BenefAddr2.PadRight(35) + BenefAddr3.PadRight(35) + City.PadRight(35) + State.PadRight(35) + Country.PadRight(35) + ZipCode.PadRight(35) + OptFlag + IssuerCode + PayBranch + FutureDatedFlag + MISCode + ProcessingFlag + ReasonFlag + UDT1 + UDT2 + UDT3 + UDT4 + UDT5 + UDT6 + UDT7 + UDT8 + UDT9 + UDT10 + UDT11 + UDT12 + UDT13;
                                WriteText(NewLine, sNewGEFUFile);
                                //WriteToDB(NewLine, sGEFU, CFlag);
                            }

                            //Write To DB                                  

                        }
                        //Footer
                        if (strLine.Substring(0, 1) == "3")
                        {
                            if (TotDeb > 0)
                                strTotDeb = TotDeb.ToString();

                            if (TotCre > 0)
                                strTotCre = TotCre.ToString();

                            if (TotDeb > 0)
                                strDeb = NoDeb.ToString();

                            if (TotCre > 0)
                                strCre = NoCre.ToString();

                            NoDebit = strLine.Substring(1, 9);
                            NoCredit = strLine.Substring(25, 9);

                            if ((NoDeb == Double.Parse(NoDebit)) || (NoCre == Double.Parse(NoCredit)))
                            {
                                TRecType = strLine.Substring(0, 1);
                                NoDebit = strLine.Substring(1, 9);
                                NoDebit = NoDebit.Trim();
                                NoDebit = NoDebit.ToString().PadLeft(9, '0');
                                TotalDebit = strLine.Substring(10, 15);
                                TotalDebit = TotalDebit.Trim();
                                TotalDebit = TotalDebit.ToString().PadLeft(15, '0');
                                NoCredit = strLine.Substring(25, 9);
                                NoCredit = NoCredit.Trim();
                                NoCredit = NoCredit.ToString().PadLeft(9, '0');
                                TotalCredit = strLine.Substring(34, 15);
                                TotalCredit = TotalCredit.Trim();
                                TotalCredit = TotalCredit.ToString().PadLeft(15, '0');
                                strLine = TRecType + NoDebit + TotalDebit + NoCredit + TotalCredit;
                                WriteText(strLine, sNewGEFUFile);
                                //WriteToDBFooter(strLine, sGEFU);
                            }
                            else
                            {
                                TRecType = strLine.Substring(0, 1);
                                if (NoDeb > 0)
                                {
                                    NoDebit = NoDebit.Trim();
                                    NoDebit = NoDeb.ToString().PadLeft(9, '0');
                                    NoCredit = NoCredit.Trim();
                                    NoCredit = NoCre.ToString().PadLeft(9, '0');
                                    TotalDebit = TotalDebit.Trim();
                                    TotalDebit = strTotDeb.ToString().PadLeft(15, '0');
                                    TotalCredit = TotalCredit.Trim();
                                    TotalCredit = strTotCre.ToString().PadLeft(15, '0');
                                }
                                else
                                {
                                    TRecType = strLine.Substring(0, 1);
                                    NoDebit = strLine.Substring(1, 9);
                                    NoDebit = NoDebit.Trim();
                                    NoDebit = NoDebit.ToString().PadLeft(9, '0');
                                    TotalDebit = strLine.Substring(10, 15);
                                    TotalDebit = TotalDebit.Trim();
                                    TotalDebit = TotalDebit.ToString().PadLeft(15, '0');
                                    NoCredit = strLine.Substring(25, 9);
                                    NoCredit = NoCredit.Trim();
                                    NoCredit = NoCredit.ToString().PadLeft(9, '0');
                                    TotalCredit = strLine.Substring(34, 15);
                                    TotalCredit = TotalCredit.Trim();
                                    TotalCredit = TotalCredit.ToString().PadLeft(15, '0');
                                    WriteText(strLine, sNewGEFUFile);
                                }
                                if (NoCre > 0)
                                {
                                    NoDebit = NoDebit.Trim();
                                    NoDebit = NoDeb.ToString().PadLeft(9, '0');
                                    NoCredit = NoCredit.Trim();
                                    NoCredit = NoCre.ToString().PadLeft(9, '0');
                                    TotalDebit = TotalDebit.Trim();
                                    TotalDebit = strTotDeb.ToString().PadLeft(15, '0');
                                    TotalCredit = TotalCredit.Trim();
                                    TotalCredit = strTotCre.ToString().PadLeft(15, '0');
                                }
                                else
                                {
                                    TRecType = strLine.Substring(0, 1);
                                    NoDebit = strLine.Substring(1, 9);
                                    NoDebit = NoDebit.Trim();
                                    NoDebit = NoDebit.ToString().PadLeft(9, '0');
                                    TotalDebit = strLine.Substring(10, 15);
                                    TotalDebit = TotalDebit.Trim();
                                    TotalDebit = TotalDebit.ToString().PadLeft(15, '0');
                                    NoCredit = strLine.Substring(25, 9);
                                    NoCredit = NoCredit.Trim();
                                    NoCredit = NoCredit.ToString().PadLeft(9, '0');
                                    TotalCredit = strLine.Substring(34, 15);
                                    TotalCredit = TotalCredit.Trim();
                                    TotalCredit = TotalCredit.ToString().PadLeft(15, '0');
                                    WriteText(strLine, sNewGEFUFile);
                                }
                                strLine = TRecType + NoDebit + TotalDebit + NoCredit + TotalCredit;
                                WriteText(strLine, sNewGEFUFile);
                                //WriteToDBFooter(strLine, sGEFU);
                            }
                        }
                    }
                    System.GC.Collect();
                    System.GC.WaitForPendingFinalizers();
                    //File.Delete(strFile);
                    Console.WriteLine("GEFU File converted successfully..");
                    return retVal;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: File does not exists on path. Original error: " + ex.Message);
                    //result = customMessage.Text("Error Message", "Error Source: " + ex.Source + " Original Error: " + ex.Message, "info", MessageBoxButtons.OK);
                }
                //Header                
            }
        exitme:
            return retVal;
        }

        public void WriteText(string newLine, string sFile)
        {
            string NEW_FILENAME = sFile.Trim();
            //string NEW_FILENAME = FILE_NAME.Substring(0, FILE_NAME.Length - 4) + "_CONVERTED.txt";

            if (!System.IO.File.Exists(NEW_FILENAME))
            {
                System.IO.File.Create(NEW_FILENAME).Dispose();
                System.IO.StreamWriter tw = new System.IO.StreamWriter(NEW_FILENAME);
                tw.WriteLine(newLine);
                tw.Close();
            }
            else if (System.IO.File.Exists(NEW_FILENAME))
            {
                System.IO.StreamWriter tw = new System.IO.StreamWriter(NEW_FILENAME, true);
                tw.WriteLine(newLine);
                tw.Close();
            }
        }


    }
}
