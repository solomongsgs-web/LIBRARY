﻿using CCAM.Data;
using CCAM.Models;
using CCAM.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing.Constraints;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Xml.Linq;
using WinSCP;
using static System.Net.Mime.MediaTypeNames;

namespace CCAM.Controllers
{
    public class DETController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _hostingEnvironment;
        private readonly SftpService _sftpService;
        private readonly FileConversionService _fileConversionService;
        private readonly AppDBContext _context;
        int processFileCtr = 0;



        public DETController(IConfiguration configuration, IWebHostEnvironment hostingEnvironment, SftpService sftpService, FileConversionService fileConversionService, AppDBContext context)
        {
            _configuration = configuration;
            _hostingEnvironment = hostingEnvironment;
            _sftpService = sftpService;
            _fileConversionService = fileConversionService;
            _context = context;
        }
        public IActionResult Index()
        {
            var viewModel = new FileListViewModel();
            string LocalDownloadPath = "det_uploads";
            string OutputFilePath = "det_converted";
            var folder1Path = Path.Combine(_hostingEnvironment.WebRootPath, path2: LocalDownloadPath);
            var folder2Path = Path.Combine(_hostingEnvironment.WebRootPath, path2: OutputFilePath);

            // Get files from Folder 1
            if (Directory.Exists(folder1Path))
            {
                viewModel.Folder1Files = Directory.GetFiles(folder1Path)
                    .Select(filePath => new SftpFileInfo
                    {
                        FileName = Path.GetFileName(filePath),
                        FileSize = Path.GetFileName(filePath).Length,
                        IsSelected = false
                    })
                    .ToList();
            }
            else
            {
                Directory.CreateDirectory(folder1Path);
                viewModel.Folder1Files = new List<SftpFileInfo>();
            }




            int sftpFilesCtr = viewModel.Folder1Files.Count;
            if (sftpFilesCtr > 0)
            {
                TempData["Message1"] = "There are " + sftpFilesCtr.ToString() + " DET MFT file for splitting.";
            }

            // Get files from Folder 2
            if (Directory.Exists(folder2Path))
            {
                viewModel.Folder2Files = Directory.GetFiles(folder2Path)
                    .Select(filePath => new SftpFileInfo
                    {
                        FileName = Path.GetFileName(filePath),
                        FileSize = Path.GetFileName(filePath).Length,
                        IsSelected = false
                    })
                    .ToList();
            }
            else
            {
                Directory.CreateDirectory(folder2Path);
                viewModel.Folder2Files = new List<SftpFileInfo>();
            }
            int outFilesCtr = viewModel.Folder2Files.Count;
            if (outFilesCtr > 0)
            {
                TempData["Message2"] = outFilesCtr.ToString() + " files was splitted";
            }
            viewModel.LocalPath = folder1Path;
            viewModel.OutputPath = folder2Path;
            viewModel.EventDateTime = DateTime.Now;
            if (TempData["Message1"] != null)
            {
                ViewBag.Message1 = TempData["Message1"];  // Pass to the view
            }
            if (TempData["Message2"] != null)
            {
                ViewBag.Message2 = TempData["Message2"];  // Pass to the view
            }
            if (TempData["StatusMessage"] != null)
            {
                ViewBag.Message3 = TempData["StatusMessage"];  // Pass to the view
            }
            return View(viewModel);
        }

        //Download ZIP files
        [HttpGet]
        public IActionResult DownloadSelectedFiles(FileListViewModel model)
        {
          
            var blnDownloadStatus = true;
            // Access selected files on RAW GEFU LISTS: model.Files.Where(f => f.IsSelected)
            var selectedFiles = model.Folder2Files.Where(f => f.IsSelected).ToList();
            // Add your logic to process the selected files here
            int count = selectedFiles.Count;
            for (int ctr = 0; ctr <= count - 1; ctr++)
            {
                // Handles the file download request
                if (string.IsNullOrEmpty(selectedFiles[ctr].FileName.ToString()))
                {
                    return BadRequest("File name is required.");
                }
                try
                {
                    string strFileName = selectedFiles[ctr].FileName.ToString();
                    var SourceFileFullPath = Path.Combine(_hostingEnvironment.WebRootPath, "det_converted", strFileName);

                  
                    if (!System.IO.File.Exists(SourceFileFullPath))
                    {
                        return NotFound();
                    }

                    // Determine the MIME type (optional, "application/octet-stream" forces a download dialog)
                    // You can use a utility to get the correct MIME type based on file extension if needed.
                    var mimeType = "application/zip";

                    // Return the file using a FileStream
                    var fileStream = new FileStream(SourceFileFullPath, FileMode.Open);

                    // The third argument (fileName) forces the browser to download the file 
                    // with the specified name, rather than displaying it in the browser.
                    return File(fileStream, mimeType, strFileName);

                }
                catch (Exception ex)
                {
                    // Handle exceptions (e.g., file not found, connection error)
                    return StatusCode(500, $"An error occurred during the download: {ex.Message}");
                }
                 
            }

            return RedirectToAction("Index");
        }

        //Convert files 
        [HttpPost]
        public IActionResult ProcessSelectedFiles(FileListViewModel model)
        {
            ViewBag.Message1 = "";
            ViewBag.Message2 = "";
            ViewBag.Message3 = "";
            var blnProcessStatus = true;
            // Access selected files on RAW GEFU LISTS: model.Files.Where(f => f.IsSelected)
            var selectedFiles = model.Folder1Files.Where(f => f.IsSelected).ToList();
            // Add your logic to process the selected files here
            int count = selectedFiles.Count;
            for (int ctr = 0; ctr <= count - 1; ctr++)
            {
                // Handles the file download request
                if (string.IsNullOrEmpty(selectedFiles[ctr].FileName.ToString()))
                {
                    return BadRequest("File name is required.");
                }
                try
                {
                    string strFileName = selectedFiles[ctr].FileName.ToString();
                    var SourceFileFullPath = Path.Combine(_hostingEnvironment.WebRootPath, "det_uploads", strFileName);

                    //blnProcessStatus = ConvertGEFUFile(selectedFiles[ctr].FileName.ToString());
                    SplitSelectedFile(SourceFileFullPath);


                    MoveSplittedFiles();

                    DownloadFolderAsZip();

                    if (TempData["Message1"] != null)
                    {
                        ViewBag.Message1 = TempData["Message1"];  // Pass to the view
                    }
                    if (TempData["Message2"] == null)
                    {
                        TempData["Message2"] = processFileCtr.ToString() + " files was converted";
                        ViewBag.Message2 = TempData["Message2"];  // Pass to the view
                    }
                    if (TempData["StatusMessage"] != null)
                    {
                        ViewBag.Message3 = TempData["StatusMessage"];  // Pass to the view
                    }
                }
                catch (Exception ex)
                {
                    // Handle exceptions (e.g., file not found, connection error)
                    return StatusCode(500, $"An error occurred during the download: {ex.Message}");
                }
                Console.WriteLine($"Selected file: {selectedFiles[ctr].FileName}");
            }
            //DONE CONVERTING 

            var folder1Path = Path.Combine(_hostingEnvironment.WebRootPath, path2: _configuration.GetSection("SftpSettings")["LocalDownloadPath"]);
            string folderPath = Path.Combine(_hostingEnvironment.WebRootPath, "text");
            string[] filePaths = Directory.GetFiles(folder1Path);

            // Or another folder
            //string fullPath = Path.Combine(folderPath, fileName);
            int counter = filePaths.Length;
            for (int ctr = 0; ctr <= counter - 1; ctr++)
            {
                string sFileName = filePaths[ctr].ToString();
                if (System.IO.File.Exists(sFileName)) 
                {
                    System.IO.File.Delete(sFileName);

                }
            }
            // Perform actions with the selected files (e.g., download, delete)
            // ...
            return RedirectToAction("Index"); // Redirect back or to a confirmation page
        }



        [HttpPost]
        public async Task<IActionResult> UploadFile(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return Content("No file selected");
            string LocalDownloadPath = "det_uploads";
            string OutputFilePath = "det_converted";
            var folder1Path = Path.Combine(_hostingEnvironment.WebRootPath, path2: LocalDownloadPath);
            var folder2Path = Path.Combine(_hostingEnvironment.WebRootPath, path2: OutputFilePath);

            // Option A: Save file to a folder
            var path = Path.Combine(_hostingEnvironment.WebRootPath, "det_uploads", file.FileName);
            using (var stream = new FileStream(path, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }
            return RedirectToAction("Index");
        }

        public IActionResult MoveSplittedFiles()
        {
            string LocalDownloadPath = "det_uploads";
            string OutputFilePath = "det_converted";
            var folder1Path = Path.Combine(_hostingEnvironment.WebRootPath, path2: LocalDownloadPath);
            var folder2Path = Path.Combine(_hostingEnvironment.WebRootPath, path2: OutputFilePath);

            // MOVE FILES
            string myDate = DateTime.Now.ToShortDateString();
            string[] pdate = myDate.Split('/');
            string strDD = pdate[0].ToString();
            string strMM = pdate[1].ToString();
            string strYY = pdate[2].ToString();
            string sDate = strYY + strMM + strDD;
            string newDate = string.Empty;
            //20201210
            strDD = sDate.Substring(6, 2).ToString();
            strMM = sDate.Substring(4, 2).ToString();
            strYY = sDate.Substring(0, 4).ToString();
            //MAR 25, 2022
            switch (strMM)
            {
                case "01":
                    newDate = "JANUARY";
                    break;
                case "02":
                    newDate = "FEBRUARY";
                    break;
                case "03":
                    newDate = "MARCH";
                    break;
                case "04":
                    newDate = "APRIL";
                    break;
                case "05":
                    newDate = "MAY";
                    break;
                case "06":
                    newDate = "JUNE";
                    break;
                case "07":
                    newDate = "JULY";
                    break;
                case "08":
                    newDate = "AUGUST";
                    break;
                case "09":
                    newDate = "SEPTEMBER";
                    break;
                case "10":
                    newDate = "OCTOBER";
                    break;
                case "11":
                    newDate = "NOVEMBER";
                    break;
                case "12":
                    newDate = "DECEMBER";
                    break;
            }
            string MonthFolder = newDate;
            MonthFolder = MonthFolder + " " + strYY;


            string strSplittedPath = "C:" + "\\" + "PCHC REPORTS" + "\\" + "PCHC REPORTS" + "\\" + MonthFolder + "\\" + strMM + strDD + strYY;
            // Get files from Folder 2
            if (Directory.Exists(strSplittedPath))
            {
                string[] filePaths = Directory.GetFiles(strSplittedPath);
                List<SftpFileInfo> files = new List<SftpFileInfo>();

                int count = filePaths.Length;
                 
                foreach (string filePath in filePaths)
                {
                    // Handles the file download request
                    if (string.IsNullOrEmpty(filePath.ToString()))
                    {
                        return BadRequest("File name is required.");
                    }
                    try
                    {
                        //Get File and Move
                        string strFileName = filePath.ToString();
                        if (strFileName.Length > 0)
                        {
                            string[] words = strFileName.Split("\\");

                            if (words[5].ToString().Contains("DET") == true)
                            {
                                var DestinationPath = Path.Combine(_hostingEnvironment.WebRootPath, "det_converted");
                                string TargetFilePath = DestinationPath + "\\" + words[5];

                                System.IO.File.Move(strFileName, TargetFilePath);

                                
                            }
                            else
                            {
                                System.IO.File.Delete(strFileName);
                            }
                        }
                    }
                    catch
                    { }

                }
            }
            else
            {
                Directory.CreateDirectory(folder2Path);
            }

            return View();
        }

        public IActionResult DownloadFolderAsZip()
        {
            var sourceFolderPath = Path.Combine(_hostingEnvironment.WebRootPath, "det_converted"); // e.g., "wwwroot/YourFolderName"
            var zipFileName = $"DET_Archive-{DateTime.Now.ToString("yyyy-MM-dd")}.zip";          
            
            var zipPath = Path.Combine(Path.GetTempPath(), zipFileName); // Create the zip in a temp path

            // Ensure the source folder exists
            if (!Directory.Exists(sourceFolderPath))
            {
                return NotFound("Source folder not found.");
            }

            try
            {
                // Create the zip file from the directory
                ZipFile.CreateFromDirectory(sourceFolderPath, zipPath, CompressionLevel.Fastest, true);

                // Return the created zip file for download
                return File(System.IO.File.ReadAllBytes(zipPath), "application/zip", zipFileName);

            }
            catch (Exception ex)
            {
                // Log the exception (ex)
                return BadRequest($"Error zipping folder: {ex.Message}");
            }
            finally
            {
                // Clean up the temporary zip file after it's been sent
                if (System.IO.File.Exists(zipPath))
                {
                    var DestFolderPath = Path.Combine(_hostingEnvironment.WebRootPath, "det_converted");
                    DestFolderPath = DestFolderPath + "\\" + zipFileName;
                    System.IO.File.Move(zipPath, DestFolderPath);
                    System.IO.File.Delete(zipPath);

                    //Delete all DET files except ZIP
                    DestFolderPath = Path.Combine(_hostingEnvironment.WebRootPath, "det_converted");
                    // Get files from Folder 2
                    if (Directory.Exists(DestFolderPath))
                    {
                        string[] filePaths3 = Directory.GetFiles(DestFolderPath);
                        List<SftpFileInfo> files = new List<SftpFileInfo>();

                        foreach (string filePath3 in filePaths3)
                        {
                            //Get File and Move
                            string sFileName = filePath3.ToString();
                            if (sFileName.Length > 0)
                            {
                             
                                if (sFileName.ToString().Contains(".DET") == true)
                                {
                                    System.IO.File.Delete(sFileName);
                                }
                            }
                        }
                    }
                }
            }
 
        }
        public IActionResult SplitSelectedFile(string newLine)
        {
            try
            {
                //MOVE FILES 
                string myDate = DateTime.Now.ToShortDateString();
                string[] pdate = myDate.Split('/');
                string strDD = pdate[0].ToString();
                string strMM = pdate[1].ToString();
                string strYY = pdate[2].ToString();
                string sDate = strYY + strMM + strDD;
                string newDate = string.Empty;
                //20201210
                strDD = sDate.Substring(6, 2).ToString();
                strMM = sDate.Substring(4, 2).ToString();
                strYY = sDate.Substring(0, 4).ToString();
                //MAR 25, 2022
                switch (strMM)
                {
                    case "01":
                        newDate = "JANUARY";
                        break;
                    case "02":
                        newDate = "FEBRUARY";
                        break;
                    case "03":
                        newDate = "MARCH";
                        break;
                    case "04":
                        newDate = "APRIL";
                        break;
                    case "05":
                        newDate = "MAY";
                        break;
                    case "06":
                        newDate = "JUNE";
                        break;
                    case "07":
                        newDate = "JULY";
                        break;
                    case "08":
                        newDate = "AUGUST";
                        break;
                    case "09":
                        newDate = "SEPTEMBER";
                        break;
                    case "10":
                        newDate = "OCTOBER";
                        break;
                    case "11":
                        newDate = "NOVEMBER";
                        break;
                    case "12":
                        newDate = "DECEMBER";
                        break;
                }
                string MonthFolder =  newDate;
                MonthFolder = MonthFolder + " " + strYY;

                //Move uploaded file to Source Path 
                //source file 
             
                string strUploadPath = newLine;
                
                string strSourcePath = "C:" + "\\" + "PCHC REPORTS" + "\\" + "PCHC REPORTS" + "\\" + MonthFolder + "\\" + strMM + strDD + strYY + "\\01008000.MTF";

                if (System.IO.File.Exists(strUploadPath)) 
                {
                    if (System.IO.File.Exists(strSourcePath))
                    {
                        System.IO.File.Delete(strSourcePath);
                    }
             
                    //Move
                    System.IO.File.Move(strUploadPath, strSourcePath);

                }
         
                // Get the full path to the executable
                string executablePath = Path.Combine(_hostingEnvironment.ContentRootPath, "wwwroot\\files", "DETSplitterEX.exe");

                // Configure the process start information
                ProcessStartInfo startInfo = new ProcessStartInfo
                {
                    FileName = executablePath,
                    Arguments = "your_arguments_here", // Optional: pass arguments to the executable
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true, // Prevents a new window from opening
                    WorkingDirectory = Path.GetDirectoryName(executablePath) // Set the working directory
                };

                // Start the process
                using (Process process = Process.Start(startInfo))
                {
                    // Optional: Read output from the executable
                    string output = process.StandardOutput.ReadToEnd();
                    process.WaitForExit(); // Wait for the executable to complete

                    // Handle the output or result as needed
                    ViewBag.Output = output;
                    return View();
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                ViewBag.Error = ex.Message;
                return View("Error");
            }
        }

    }
}
