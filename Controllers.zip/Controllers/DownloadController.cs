﻿using Microsoft.AspNetCore.Mvc;
using CCAM.Models;
using CCAM.Services;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using WinSCP;
using SessionOptions = WinSCP.SessionOptions;

namespace CCAM.Controllers
{
    public class DownloadController : Controller
    {
            private readonly WinScpService _winScpService;
            private readonly SftpService _sftpService;
            private readonly IConfiguration _configuration;
            private readonly IWebHostEnvironment _hostingEnvironment;
            public DownloadController(WinScpService winScpService, SftpService sftpService, IConfiguration configuration, IWebHostEnvironment hostingEnvironment)
            {
                _winScpService = winScpService;
                _sftpService = sftpService;
                _configuration = configuration;
                _hostingEnvironment = hostingEnvironment;
            }

            [HttpGet]
            public IActionResult Index()
            {
                var viewModel = new SftpFileListViewModel();
                var localDownloadPath = Path.Combine(_hostingEnvironment.WebRootPath, path2: _configuration.GetSection("SftpSettings")["LocalDownloadPath"]);
       
                // Get the path to your local directory (e.g., inside wwwroot)
                string localDirectoryPath = localDownloadPath; //Path.Combine(_env.WebRootPath, "LocalFiles");

                // Ensure the directory exists
                if (Directory.Exists(localDirectoryPath))
                {
#pragma warning disable CS8619 // Nullability of reference types in value doesn't match target type.

                     
                    viewModel.LocalFiles = Directory.GetFiles(localDirectoryPath)
                        .Select(Path.GetFileName); // Get only the file name
#pragma warning restore CS8619 // Nullability of reference types in value doesn't match target type.
                }
                else
                {
                    Directory.CreateDirectory(localDirectoryPath);
                    viewModel.LocalFiles = new List<string>();
                }


                //FOR SFTP
                var sessionOptions = new SessionOptions
                {
                    Protocol = Protocol.Sftp,
                    HostName = _configuration.GetSection("SftpSettings")["Host"],
                    UserName = _configuration.GetSection("SftpSettings")["Username"],
                    Password = _configuration.GetSection("SftpSettings")["Password"],
                    SshHostKeyFingerprint = _configuration.GetSection("SftpSettings")["SshHostKeyFingerprint"] //"ssh-rsa 2048 xxxxxxxxxxx..." // Get this from your server
                };
                var _remotePath = _configuration.GetSection("SftpSettings")["RemoteFilePath"];
                try
                {
                    using (var session = new Session())
                    {
                        session.Open(sessionOptions);

                        var directoryInfo = session.ListDirectory(_remotePath);

                        viewModel.Files = directoryInfo.Files
                            .Where(f => !f.IsDirectory)    // && !f.IsSymbolicLink)
                            .Select(f => new SftpFileInfo
                            {
                                FileName = f.Name,
                                FileSize = f.Length,
                                LastModified = f.LastWriteTime,
                                IsSelected = false // Initialize as not selected
                            })
                            .ToList();
                    }
                }
                catch (SessionRemoteException ex)
                {
                    // Handle exceptions appropriately
                    ModelState.AddModelError("", $"Could not list directory: {ex.Message}");
                    viewModel.Files = new List<SftpFileInfo>();
                }
                viewModel.LocalPath = localDownloadPath;
                viewModel.RemotePath = _remotePath;
                return View(viewModel);
            }


            [HttpPost]
            public IActionResult ProcessFiles(SftpFileListViewModel model)
            {
                //var localDownloadPath = _configuration.GetSection("SftpSettings")["LocalDownloadPath"];
                var remotePath = _configuration.GetSection("SftpSettings")["RemoteFilePath"];
                var localDownloadPath = Path.Combine(_hostingEnvironment.WebRootPath, path2: _configuration.GetSection("SftpSettings")["LocalDownloadPath"]);

                Directory.CreateDirectory(localDownloadPath);

                var selectedFiles = model.Files.Where(f => f.IsSelected).ToList();
                // Add your logic to process the selected files here
                int count = selectedFiles.Count;
                for (int ctr = 0; ctr < count; ctr++)
                {
                    // Handles the file download request
                    if (string.IsNullOrEmpty(selectedFiles[ctr].FileName.ToString()))
                    {
                        return BadRequest("File name is required.");
                    }
                    try
                    {
                        _sftpService.DownloadFile(selectedFiles[ctr].FileName.ToString(), localDownloadPath);

                    }
                    catch (Exception ex)
                    {
                        // Handle exceptions (e.g., file not found, connection error)
                        return StatusCode(500, $"An error occurred during the download: {ex.Message}");
                    }
                    Console.WriteLine($"Selected file: {selectedFiles[ctr].FileName}");
                }
                // Serve the downloaded file to the user
                //var filePath = Path.Combine(localDownloadPath, selectedFiles[count-1].FileName.ToString());
                //var fileBytes = System.IO.File.ReadAllBytes(filePath);
                //return File(fileBytes, "application/octet-stream", selectedFiles[count-1].FileName.ToString());
                // For example, download them, delete them, etc.
                return RedirectToAction("Index");
            }

            [HttpPost]
            public IActionResult ProcessSelectedFiles(List<SftpFileInfo> selectedFiles)
            {
                // Process the selected files (e.g., download, delete)
                foreach (var file in selectedFiles.Where(f => f.IsSelected))
                {
                    // Perform actions on selected files
                    Console.WriteLine($"Selected file: {file.FileName}");
                }

                return RedirectToAction("Index"); // Redirect back to the file list
            }
      }
}
